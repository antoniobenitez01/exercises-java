package saludos;

public class Saludo {

}
